﻿namespace LibraryItems
{
    partial class editBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.editBookList = new System.Windows.Forms.ListBox();
            this.editBookSelectButton = new System.Windows.Forms.Button();
            this.editBookCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // editBookList
            // 
            this.editBookList.Dock = System.Windows.Forms.DockStyle.Left;
            this.editBookList.FormattingEnabled = true;
            this.editBookList.ItemHeight = 20;
            this.editBookList.Location = new System.Drawing.Point(0, 0);
            this.editBookList.Name = "editBookList";
            this.editBookList.Size = new System.Drawing.Size(449, 450);
            this.editBookList.TabIndex = 0;
            // 
            // editBookSelectButton
            // 
            this.editBookSelectButton.Location = new System.Drawing.Point(535, 99);
            this.editBookSelectButton.Name = "editBookSelectButton";
            this.editBookSelectButton.Size = new System.Drawing.Size(130, 51);
            this.editBookSelectButton.TabIndex = 1;
            this.editBookSelectButton.Text = "Select";
            this.editBookSelectButton.UseVisualStyleBackColor = true;
            this.editBookSelectButton.Click += new System.EventHandler(this.editBookSelectButton_Click);
            // 
            // editBookCancel
            // 
            this.editBookCancel.Location = new System.Drawing.Point(535, 248);
            this.editBookCancel.Name = "editBookCancel";
            this.editBookCancel.Size = new System.Drawing.Size(130, 51);
            this.editBookCancel.TabIndex = 2;
            this.editBookCancel.Text = "Cancel";
            this.editBookCancel.UseVisualStyleBackColor = true;
            this.editBookCancel.Click += new System.EventHandler(this.editBookCancel_Click);
            // 
            // editBookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 450);
            this.Controls.Add(this.editBookCancel);
            this.Controls.Add(this.editBookSelectButton);
            this.Controls.Add(this.editBookList);
            this.Name = "editBookForm";
            this.Text = "Choose Book To Edit";
            this.Load += new System.EventHandler(this.editBookForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox editBookList;
        private System.Windows.Forms.Button editBookSelectButton;
        private System.Windows.Forms.Button editBookCancel;
    }
}