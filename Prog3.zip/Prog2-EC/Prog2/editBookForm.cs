﻿// Program 3
// CIS 200-01
// Due: 4/5/2018
// By: Z8360

// File: editBookForm.cs
// creates a form to select a book to edit
// opens bookform then sends new info back to this form then to main form

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class editBookForm : Form
    {

        public string ReturnTitle { get; set; } // properties used to make book title public
        public string ReturnPublisher { get; set; } // properties used to make book publisher public
        public int ReturnCR { get; set; }  // properties used to make book copyright year public
        public int ReturnLP { get; set; }  // properties used to make book loan period public
        public string ReturnCN { get; set; } // properties used to make book call numbner public
        public string ReturnAuthor { get; set; } // properties used to make book author public
        public int ReturnEditBookIndex { set; get; } // used for editing specific book
        private List<LibraryItem> _items;    // List of library items
        private List<int> bookIndices; // List of index values of books

        public editBookForm(List<LibraryItem>itemList)
        {
            InitializeComponent();

            _items = itemList; // sets private list = to _lib's item list
            bookIndices = new List<int>(); // instantiates bookindices


        }

        internal int ItemIndex
        {
            // Precondition:  None
            // Postcondition: The index of form's selected item combo box has been returned
            get
            {
                if (editBookList.SelectedIndex != -1)
                    return bookIndices[editBookList.SelectedIndex]; // Lookup correct index

                // Should never happen if validation works
                return -1;
            }
        }

        // Precondition:  selected a book
        // Postcondition: The index and properties of form's selected book combo box has been returned
        private void editBookSelectButton_Click(object sender, EventArgs e)
        {
            if (editBookList.SelectedIndex == -1)
            {
                MessageBox.Show("You MUST select a book to edit");
            }
            else
            {
                ReturnEditBookIndex = editBookList.SelectedIndex;

                BookForm bookForm = new BookForm(); // The book dialog box form

                DialogResult result = bookForm.ShowDialog(); // Show form as dialog and store result


                if (result == DialogResult.OK) // Only add if OK
                {
                    try
                    {
                        // Use this form's properties to get book info from bookform to send to library
                        ReturnTitle = bookForm.ItemTitle;
                        ReturnPublisher = bookForm.ItemPublisher;
                        ReturnCR = int.Parse(bookForm.ItemCopyrightYear);
                        ReturnLP = int.Parse(bookForm.ItemLoanPeriod);
                        ReturnCN = bookForm.ItemCallNumber;
                        ReturnAuthor = bookForm.BookAuthor;
                        this.DialogResult = DialogResult.OK; // sets the dialoge result to OK
                        this.Close(); // closes checkout form
                    }

                    catch (FormatException) // This should never happen if form validation works!
                    {
                        MessageBox.Show("Problem with Book Validation!", "Validation Error");
                    }
                }

                bookForm.Dispose(); // Good .NET practice - will get garbage collected anyway
            }
        }
        //pre: form loads
        //post: populates list with books
        private void editBookForm_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < _items.Count; ++i)
            {
                if (_items[i].GetType()== typeof(LibraryBook)) // Checked out, so OK to include
                {
                    editBookList.Items.Add(_items[i].Title + ", " + _items[i].CallNumber);
                    bookIndices.Add(i); // Keep track of location
                }
            }
        }
        //pre: form is open
        //post: form is closed
        private void editBookCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; // sets the dialoge result to Cancel

            this.Close(); // closes checkout form
        }
    }
}
