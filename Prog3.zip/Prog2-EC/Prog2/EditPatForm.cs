﻿// Program 3
// CIS 200-01
// Due: 4/5/2018
// By: Z8360

// File: editBookForm.cs
// creates a form to select a patron to edit
// opens patronform then sends new info back to this form then to main form
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LibraryItems
{
    public partial class EditPatForm : Form
    {
        public string ReturnEditPatName { get; set; } // properties used to make Patron name
        public string ReturnEditPatID { get; set; } // properties used to make Patron id
        public int ReturnEditPatIndex { get; set; } // property to send list box index

        public EditPatForm(Library _lib)
        {
            InitializeComponent();

            foreach (LibraryPatron patron in _lib.GetPatronsList()) // displays patron name and id in patroncombobox
            {

                this.editPatronList.Items.Add($"{patron.PatronName} , {patron.PatronID}");
            }
        }

        //pre: this form has been opened
        //post: pat id updated
        private void editPatConfirm_Click(object sender, EventArgs e)
        {
                

            if (editPatronList.SelectedIndex == -1)  // makes it so that you have to select a patron
                MessageBox.Show("You MUST select a patron to edit");
            else // closes box and sets public properties
            {
                PatronForm patronForm = new PatronForm(); // The patron dialog box form

                DialogResult result = patronForm.ShowDialog(); // Show form as dialog and store result

                if (result == DialogResult.OK) // Only add if OK
                {
                    // Use form's properties to get patron info to send to library
                  
                    this.ReturnEditPatIndex = editPatronList.SelectedIndex;
                    this.ReturnEditPatName = patronForm.PatronName; // uses checkout property to return itemindex
                    this.ReturnEditPatID = patronForm.PatronID; // uses checkout property to return patronindex
                    this.DialogResult = DialogResult.OK; // sets the dialoge result to OK
                    this.Close(); // closes checkout form
                }

                patronForm.Dispose(); // Good .NET practice - will get garbage collected anyway
               
            }
        }
        //pre: form is open
        //post: form is closed
        private void editPatCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel; // sets the dialoge result to Cancel

            this.Close(); // closes checkout form
        }
    }
}
