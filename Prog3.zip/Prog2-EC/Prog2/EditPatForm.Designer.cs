﻿namespace LibraryItems
{
    partial class EditPatForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.editPatronList = new System.Windows.Forms.ListBox();
            this.editPatConfirm = new System.Windows.Forms.Button();
            this.editPatCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // editPatronList
            // 
            this.editPatronList.FormattingEnabled = true;
            this.editPatronList.ItemHeight = 20;
            this.editPatronList.Location = new System.Drawing.Point(12, 12);
            this.editPatronList.Name = "editPatronList";
            this.editPatronList.Size = new System.Drawing.Size(327, 424);
            this.editPatronList.TabIndex = 0;
            // 
            // editPatConfirm
            // 
            this.editPatConfirm.Location = new System.Drawing.Point(369, 98);
            this.editPatConfirm.Name = "editPatConfirm";
            this.editPatConfirm.Size = new System.Drawing.Size(178, 57);
            this.editPatConfirm.TabIndex = 1;
            this.editPatConfirm.Text = "Select";
            this.editPatConfirm.UseVisualStyleBackColor = true;
            this.editPatConfirm.Click += new System.EventHandler(this.editPatConfirm_Click);
            // 
            // editPatCancel
            // 
            this.editPatCancel.Location = new System.Drawing.Point(369, 221);
            this.editPatCancel.Name = "editPatCancel";
            this.editPatCancel.Size = new System.Drawing.Size(178, 57);
            this.editPatCancel.TabIndex = 6;
            this.editPatCancel.Text = "Cancel";
            this.editPatCancel.UseVisualStyleBackColor = true;
            this.editPatCancel.Click += new System.EventHandler(this.editPatCancel_Click);
            // 
            // EditPatForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 450);
            this.Controls.Add(this.editPatCancel);
            this.Controls.Add(this.editPatConfirm);
            this.Controls.Add(this.editPatronList);
            this.Name = "EditPatForm";
            this.Text = "Choose Patron to Edit";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox editPatronList;
        private System.Windows.Forms.Button editPatConfirm;
        private System.Windows.Forms.Button editPatCancel;
    }
}